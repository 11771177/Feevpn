document.getElementById("connect-btn").addEventListener("click", function () {
    const server = document.getElementById("server").value;
    const port = document.getElementById("port").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const configFile = document.getElementById("config-file").files[0];

    if (!configFile) {
        document.getElementById("status").innerText = "Please upload a configuration file.";
        return;
    }

    const reader = new FileReader();
    reader.onload = function (e) {
        const fileContent = e.target.result;

        // إرسال البيانات إلى الخادم أو استخدام الملف للاتصال
        fetch("http://localhost:8080/connect", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ server, port, username, password, config: fileContent })
        })
            .then(response => response.json())
            .then(data => {
                document.getElementById("status").innerText = data.message;
            })
            .catch(error => {
                document.getElementById("status").innerText = "Error: " + error.message;
            });
    };

    reader.readAsText(configFile);
});